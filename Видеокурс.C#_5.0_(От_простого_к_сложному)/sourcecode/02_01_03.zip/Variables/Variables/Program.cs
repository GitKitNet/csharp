﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variables
{
    class Program
    {
        static void Main(string[] args)
        {
            //тип_данных название_переменной
            int x = 17;
            string title = "Война и мир";
            bool jobIsDone; //значение для переменной заранее неизвестно
            // ... выполнение какого-то кода ...
            jobIsDone = false; //теперь значение для переменной известно

            Console.WriteLine(x);

            // ... выполняется какой-то код
            x = 105;
            int y = 22;
            x = y;
            Console.WriteLine(x);

            int myMoneyOnCreditCard;
            int pageCountInBook;
            int colichestvoStranicVKnige;
        }
    }
}
