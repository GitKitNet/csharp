﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 0;
            if (x > 0)
            {
                Console.WriteLine("Переменная x > 0");
            }
            else if (x == 0)
            {
                Console.WriteLine("Переменная x == 0");
            }
            else
            {
                Console.WriteLine("Переменная x < 0");
            }
        }
    }
}
