﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BooleanType
{
    class Program
    {
        static void Main(string[] args)
        {
            //bool operationIsFinished = false;
            //Console.WriteLine("Операция завершена: {0}", operationIsFinished);

            //bool result;
            //result = 5 > 6;
            //Console.WriteLine("5 > 6? {0}", result);
            //result = 18 - 2 == 16;
            //Console.WriteLine("18 - 2 == 16? {0}", result);
            //result = "snow" == "snow";
            //Console.WriteLine("snow == snow? {0}", result);
            //result = "snow" == "Snow";
            //Console.WriteLine("snow == Snow? {0}", result);

            //домашнее задание
            bool result = "с" == "С";
            Console.WriteLine(result);
        }
    }
}
