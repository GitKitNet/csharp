﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriverInterface
{
    class SchoolBoy
    {

    }

    class Student : IDriver
    {
        public void DriveToPlace(string place)
        {
            //
        }

        public void FillUpCar(int litres)
        {
            //
        }
    }

    class Worker : IDriver
    {
        public void DriveToPlace(string place)
        {
            //
        }

        public void FillUpCar(int litres)
        {
            //
        }
    }
}
