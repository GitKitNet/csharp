﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DriverInterface
{
    public interface IDriver
    {
        void DriveToPlace(string place);
        void FillUpCar(int litres);
    }
}
