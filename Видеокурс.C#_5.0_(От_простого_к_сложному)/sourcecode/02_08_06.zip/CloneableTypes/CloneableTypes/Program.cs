﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloneableTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            Worker worker1 = new Worker();
            worker1.FIO = "Иванов Иван Иванович";
            worker1.Salary = 30000;

            Worker worker2 = (Worker) worker1.Clone();

            Console.WriteLine(worker1.FIO);
            Console.WriteLine(worker2.FIO);
            worker1.FIO = "Петров Петр Петрович";
            Console.WriteLine(worker1.FIO);
            Console.WriteLine(worker2.FIO);
        }
    }

    class Worker : ICloneable
    {
        public string FIO { get; set; }
        public double Salary { get; set; }
        public object Clone()
        {
            Worker clone = new Worker();
            clone.FIO = this.FIO;
            clone.Salary = this.Salary;
            return clone;
        }
    }
}
