﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Tiger tiger1 = new Tiger();
            tiger1.Name = "Геральд";
            tiger1.Age = 7;
            tiger1.TailLength = 20;

            Elephant elephant1 = new Elephant();
            elephant1.Name = "Малыш";
            elephant1.Feed();
        }
    }
}
