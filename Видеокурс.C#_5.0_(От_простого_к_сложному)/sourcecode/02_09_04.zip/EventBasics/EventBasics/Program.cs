﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Model = "Ford Focus";
            car.FuelLevel = 15;
            car.TankIsEmpty += EventHandlerMethod;
            car.TankIsEmpty += EventHandlerMethod2;

            car.DriveToHospital();
            car.DriveToShop();
            car.DriveToWork();
            car.DriveToShop();
            car.DriveToWork();
        }

        static void EventHandlerMethod()
        {
            Console.WriteLine("Метод EventHandlerMethod() вызывается, потому что он подписан на событие TankIsEmpty");
        }
        static void EventHandlerMethod2()
        {
            Console.WriteLine("Метод EventHandlerMethod2() вызывается, потому что он подписан на событие TankIsEmpty");
        }
    }
}
