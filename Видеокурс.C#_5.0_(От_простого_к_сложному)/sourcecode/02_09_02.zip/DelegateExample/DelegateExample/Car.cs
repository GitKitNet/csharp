﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateExample
{
    public class Car
    {
        public delegate double DistanceCalculatorDelegate(double fuelLevel, double fuelConsumption1Km, double distance);

        public string Name { get; set; } //модель авто
        public double FuelLevel { get; set; } //сколько бензина в баке
        public double FuelConsumption100Km { get; set; } //расход топлива на 100км
        private double fuelConsumption1Km; //расход топлива на 1км

        public Car(string name, double fuelLevel, double fuelConsumption100km)
        {
            Name = name;
            FuelConsumption100Km = fuelConsumption100km;
            FuelLevel = fuelLevel;
            fuelConsumption1Km = FuelConsumption100Km/100*1;
        }

        public void Drive(double distance, DistanceCalculatorDelegate dDelegate)
        {
            //FuelLevel -= distance*fuelConsumption1Km;
            //if (FuelLevel <= 0)
            //    Console.WriteLine("Машина заглохла и не смогла проехать {0} км", distance);
            //else
            //    Console.WriteLine("Пройденная дистанция {0} км. Осталось топлива: {1} л", distance, FuelLevel);
            FuelLevel = dDelegate(FuelLevel, fuelConsumption1Km, distance);
        }
    }
}
