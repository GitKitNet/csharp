﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car("Ford Focus", 5, 4.6);
            car.Drive(10, Service.DistanceCalculator);
            car.Drive(5, Service.DistanceCalculator);
            car.Drive(90, Service.DistanceCalculator);
            car.Drive(100, Service.DistanceCalculator);
        }
    }
}
