﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            AddTwoNumbers();
            AddTwoNumbers();
            AddTwoNumbers();
        }

        //метод для сложения двух чисел
        static void AddTwoNumbers()
        {
            int x = 5;
            int y = 20;
            int result = x + y;
            Console.WriteLine("{0} + {1} = {2}", x, y, result);
        }
    }
}
