﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            if(DateTime.Now.Hour < 12)
                Console.WriteLine("Доброе утро!");
            else
            {
                Console.WriteLine("Добрый день!");
            }
            Console.WriteLine("Введите, пожалуйста, ваше имя и нажмите Enter: ");
            string name = Console.ReadLine();
            Console.WriteLine("Введите, пожалуйста, название блюда и нажмите Enter: ");
            string order = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Спасибо за ваш заказ, уважаемый {0}! Вы выбрали {1}", name, order);
            int time = new Random().Next(5, 20);
            Console.WriteLine("Ваш заказ будет готов через {0} минут.", time);
        }
    }
}
