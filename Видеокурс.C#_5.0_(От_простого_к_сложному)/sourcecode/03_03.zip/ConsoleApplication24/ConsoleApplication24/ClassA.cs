﻿namespace ConsoleApplication24
{
    class ClassA
    {
    }
}
