﻿using System;
using ConsoleApplication24.MyClasses;

namespace ConsoleApplication24
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("...");
            ConsoleApplication24.MyClasses.Console.WriteLine();
        }
    }
}
