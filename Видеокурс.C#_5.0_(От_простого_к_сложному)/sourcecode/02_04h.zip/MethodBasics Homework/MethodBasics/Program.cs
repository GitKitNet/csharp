﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            //int methodResult = AddTwoNumbers(3, 4);
            //TypeMessage("Hello");

            //int[] intArray = new[] {222, -5, 0, 0, 15, 1000, -2, 211};
            //Console.WriteLine(GetMaxValue(intArray));
            //Console.WriteLine(ReturnStringLength("Привет из Visual Studio"));
            Console.WriteLine(AnalyzeNumber(-100));
        }

        //метод для сложения двух чисел
        static int AddTwoNumbers(int x, int y)
        {
            int result = x + y;
            return result;
            Console.WriteLine("{0} + {1} = {2}", x, y, result);
        }

        //метод выводит на консоль сообщение
        static void TypeMessage(string message)
        {
            message = message + "!!!";
            Console.WriteLine(message);
        }

        //метод определяет максимальное из всех чисел в массиве
        static int GetMaxValue(int[] intArray)
        {
            return intArray.Max();
        }

        //метод определяет количество символов в строке текста
        static int ReturnStringLength(string myString)
        {
            return myString.Length;
        }

        //метод анализирует число
        static string AnalyzeNumber(int myNumber)
        {
            if (myNumber == 0)
                return "Число равно нулю";
            if (myNumber > 0)
                return "Число больше нуля";
            return "Число меньше нуля";
        }
    }
}
