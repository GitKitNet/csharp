﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Model = "Ford Focus";
            car.FuelLevel = 15;
            car.TankIsEmpty += delegate(string description)
                {
                    Console.WriteLine("Вызывается анонимный метод.");
                    Console.WriteLine(description);
                };
            car.TankIsEmpty += description =>
                {
                    Console.WriteLine("Вызывается лямбда-выражение.");
                    Console.WriteLine(description);
                };

            car.DriveToHospital();
            car.DriveToShop();
            car.DriveToWork();
            car.DriveToShop();
            car.DriveToWork();
        }

        //заменяем этот метод на анонимный
        //static void EventHandlerMethod()
        //{
        //    Console.WriteLine("Метод EventHandlerMethod() вызывается, потому что он подписан на событие TankIsEmpty");
        //}

        //заменяем этот метод лямбда-выражением
        //static void EventHandlerMethod2()
        //{
        //    Console.WriteLine("Метод EventHandlerMethod2() вызывается, потому что он подписан на событие TankIsEmpty");
        //}
    }
}
