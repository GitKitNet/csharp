﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventBasics
{
    class Car
    {
        public string Model { get; set; } //модель авто
        public int FuelLevel { get; set; } //сколько бензина в баке

        public delegate void EventDelegate(string description); //делегат, который используется для поддержки события
        public event EventDelegate TankIsEmpty; //событие "Бак пустой"

        public void DriveToShop()
        {
            if (FuelLevel == 0)
                TankIsEmpty("Бензин закончился по пути в магазин.");
            else
                FuelLevel -= 5;
        }
        public void DriveToWork()
        {
            if (FuelLevel == 0)
                TankIsEmpty("Бензин закончился по пути на работу.");
            else
                FuelLevel -= 5;
        }
        public void DriveToHospital()
        {
            if (FuelLevel == 0)
                TankIsEmpty("Бензин закончился по пути в больницу.");
            else
                FuelLevel -= 5;
        }
    }
}
