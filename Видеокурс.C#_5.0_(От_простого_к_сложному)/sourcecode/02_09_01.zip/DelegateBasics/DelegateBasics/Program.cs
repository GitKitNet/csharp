﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateBasics
{
    public delegate void MyFirstDelegate(string message);

    class Program
    {
        static void Main(string[] args)
        {
            //Делегат - это указатель на метод

            PrintMessage("Прямой вызов метода PrintMessage()");

            MyFirstDelegate myDelegate = new MyFirstDelegate(PrintMessage);
            myDelegate("Вызов метода PrintMessage() через делегат");

            Test test = new Test();
            MyFirstDelegate myDelegate2 = new MyFirstDelegate(test.TestMethod);
            myDelegate2("Вызов метода TestMethod() на объекте класса Test");
        }

        static void PrintMessage(string message)
        {
            Console.WriteLine(message);
        }
    }

    class Test
    {
        public void TestMethod(string message)
        {
            Console.WriteLine(message);
        }
    }
}
