﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            //int choice = 100;
            //switch (choice)
            //{
            //    case 1:
            //        Console.WriteLine("Вы выбрали пункт 1");
            //        break;
            //    case 2:
            //        Console.WriteLine("Вы выбрали пункт 2");
            //        break;
            //    default:
            //        Console.WriteLine("Ошибка! Такого пункта не существует");
            //        break;
            //}
            string answer;
            do
            {
                Console.WriteLine("Желаете ли вы провести антивирусную проверку?");
                answer = Console.ReadLine();
                switch (answer)
                {
                    case "да":
                        Console.WriteLine("... производится антивирусная проверка ...");
                        break;
                    case "нет":
                        Console.WriteLine("... риск заражения компьютера возрастает ...");
                        break;
                    default:
                        Console.WriteLine("... ошибка! неизвестная команда ...");
                        break;
                }
            } while (answer != "нет" && answer != "да");
        }
    }
}
