﻿namespace FightingClub
{
    //перечисление определяет два состояния битвы
    //NextRound - можно начинать следующий раунд
    //Stop - следуюший раунд начинать нельзя
    public enum FightState
    {
        NextRound,
        Stop
    }
}
