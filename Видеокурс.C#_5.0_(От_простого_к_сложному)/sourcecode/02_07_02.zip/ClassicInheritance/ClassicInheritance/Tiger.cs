﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicInheritance
{
    //дочерний (производный) класс Тигр
    class Tiger : Animal
    {
        public int TailLength { get; set; }

        public Tiger()
        {
        }

        public Tiger(string name, int age, int weight, int tailLength) : base (name, age, weight)
        {
            TailLength = tailLength;
        }

        public override void Feed()
        {
            base.Feed();
            Console.WriteLine("Тигра покормили мясом.");
        }
    }
}
