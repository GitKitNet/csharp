﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr1 = { 1, 2, 3, 4 };
            int[] arr2 = (int[]) arr1.Clone();
            ICloneable[] clones = {arr1, arr2, "hello", new B()};
            foreach (ICloneable clone in clones)
            {
                clone.Clone();
            }
        }
    }

    abstract class A
    {
        public string Test2 { get; set; }
        public abstract void Test();
    }
    class B : A, ICloneable
    {
        public override void Test()
        {
            //
        }

        public object Clone()
        {
            return new B();
        }
    }
}
