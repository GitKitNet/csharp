﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FightingClub
{
    //перечисление определяет два состояния битвы
    //NextRound - можно начинать следующий раунд
    //Stop - следуюший раунд начинать нельзя
    public enum FightState
    {
        NextRound,
        Stop
    }
}
