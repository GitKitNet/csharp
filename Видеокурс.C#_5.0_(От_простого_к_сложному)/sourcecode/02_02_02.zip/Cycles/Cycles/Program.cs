﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cycles
{
    class Program
    {
        static void Main(string[] args)
        {
            //цикл for
            //for (int i = 0; i < 5; i = i + 2)
            //{
            //    Console.WriteLine("Hello!"); 
            //}

            string[] letters = {"a", "b", "c", "d", "e"};
            //for (int i = 0; i < letters.Length; i++)
            //{
            //    Console.WriteLine(letters[i]);
            //}

            //домашнее задание к циклу for
            //string[] films = {"Зеленая миля", "Области тьмы", "О чем говорят мужчины"};
            //for (int i = 1; i < films.Length - 1; i++)
            //{
            //    Console.WriteLine(films[i]);
            //}

            //цикл foreach
            foreach (string letter in letters)
            {
                Console.WriteLine(letter);
            }
        }
    }
}
