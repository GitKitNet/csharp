﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structures
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }

    struct City
    {
        public string Name { get; set; }
        public int Population { get; set; }
    }
}
