﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            string surname = "Иванов";
            string name = "Иван";
            string middleName = "Иванович";
            string fio = surname + " " + name + " " + middleName;

            //способы вывода текста на консоль
            //Console.WriteLine(fio);
            //Console.WriteLine("ФИО человека:" + " " + fio);
            //Console.WriteLine("ФИО человека: {0}", fio);
            //Console.WriteLine("ФИО человека: {0} {1} {2}", surname, name, middleName);

            //конкатенация строк и арифметическое сложение
            //Console.WriteLine(3 + 4);
            //Console.WriteLine("3" + "4");

            //преобразование числа в текст и обратно
            int x = 25;
            string number = x.ToString();
            number = number + " человек";
            //Console.WriteLine(number);

            string someText = "111";
            int someNumber = 222 + int.Parse(someText);
            //Console.WriteLine(someNumber);

            //тип char
            char symbol = '5', symbol2 = '?';
            Console.WriteLine("Символ {0} является числом: {1}", symbol, char.IsDigit(symbol));
            Console.WriteLine("Символ {0} является числом: {1}", symbol2, char.IsDigit(symbol2));
            Console.WriteLine("Символ {0} является знаком пунктуации: {1}", symbol2, char.IsPunctuation(symbol2));
        }
    }
}
