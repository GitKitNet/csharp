﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FightingClub.Fighters
{
    //класс определяет общую базовую сущность "Боец"
    public abstract class Fighter
    {
        public delegate void IsDeadDelegate();
        public event IsDeadDelegate IsDead; //событие "Боец мертв"

        public string Name { get; private set; }
        public string ClassDescription { get; private set; }
        public string UltimateAbilityDescription { get; private set; }

        public int Strength { get; private set; }
        public int Damage { get; private set; }

        public int Agility { get; private set; }
        public int DodgeChance { get; private set; }

        public int Vitality { get; private set; }
        public int HP { get; private set; }

        //конструктор
        protected Fighter()
        {
            
        }

        //метод рассчитывает кол-во нанесенного урона
        public int Kick()
        {
            
        }

        //абстрактный метод "Использовать особое умение".
        //должен быть переопределен в классах-наследниках
        public abstract int UseUltimateAbility();

        //метод выводит на консоль информацию о бойце
        public virtual void ShowStats()
        {
            Console.WriteLine("Имя: {0}\nКласс: {1}\nСила: {2}\t\tЛовкость: {3}\t\tЖивучесть: {4}\nУрон: {5}\tШанс увернуться: {6}%\tHP: {7}\nУмение: {8}", Name, ClassDescription, Strength, Agility, Vitality, Damage, DodgeChance, HP, UltimateAbilityDescription);
            Console.WriteLine();
        }
    }
}
