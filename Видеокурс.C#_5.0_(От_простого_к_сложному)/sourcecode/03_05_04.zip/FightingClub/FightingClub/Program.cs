﻿using System;

namespace FightingClub
{
    class Program
    {
        static void Main()
        {
            PrintMenu();
        }

        //метод рисует главное меню
        static void PrintMenu()
        {
            Console.Clear();
            Console.WriteLine("ИГРА БОЙЦОВСКИЙ КЛУБ\n");
            Console.WriteLine("1 - начать игру");
            Console.WriteLine("2 - правила");
            Console.WriteLine("3 - выход");
            string option = Console.ReadLine();

            if (option == "1")
            {
                Game game = new Game();
                game.StartGame();
            }

            if(option == "2")
                PrintRules();

            if(option == "3")
                return;

            //рекурсия в действии
            //если пользователь ввел значение отличное от "3", 
            //то мы всегда заново вызываем метод PrintMenu() из самого себя
            PrintMenu();
        }

        //метод выводит на консоль правила игры
        static void PrintRules()
        {
            Console.Clear();
            Console.WriteLine("... правила в разработке ...");
            Console.ReadLine();
        }
    }
}
