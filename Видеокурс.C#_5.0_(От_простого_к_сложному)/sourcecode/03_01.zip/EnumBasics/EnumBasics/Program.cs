﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            Colors color = Colors.Blue;
            EnumAnalyze(color);
        }

        static void EnumAnalyze(Colors color)
        {
            Console.WriteLine("Тип перечисления: {0}", color.GetType());
            Console.WriteLine("Символьное представление переменной перечисления: {0}", color.ToString());
            Console.WriteLine("Числовое представление переменной перечисления: {0}", (int)color);
        }

        static void PaintWall(Colors color)
        {
            switch (color)
            {
                case Colors.Red:
                    Console.WriteLine("Красим стену в красный цвет");
                    break;
                case Colors.Blue:
                    Console.WriteLine("Красим стену в синий цвет");
                    break;
                case Colors.Green:
                    Console.WriteLine("Красим стену в зеленый цвет");
                    break;
            }
        }
    }

    //перечисление "Цвета"
    enum Colors
    {
        Red,    //0
        Blue,   //1
        Green   //2
    }
}
