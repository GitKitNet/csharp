﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            //int a = 2, b = 4, c = 6, d = 8, e = 10;

            ////массивы
            //int[] intArray = new int[5];
            //intArray[0] = 2;
            //intArray[1] = 4;
            //intArray[2] = 6;
            //intArray[3] = 8;
            //intArray[4] = 10;

            //int[] intArray2 = new[] {2, 4, 6, 8, 10};

            //string[] stringArray = new[] {"Однажды", "в", "студеную", "зимнюю", "пору"};
            ////Console.WriteLine("Продолжите стих: {0} {1} {2} {3} {4}...", stringArray[0], stringArray[1], stringArray[2], stringArray[3], stringArray[4]);
            ////Console.WriteLine("Продолжите стих: {0} {1} {2} {3} {4} {5}...", stringArray[0], stringArray[1], stringArray[3], stringArray[2], stringArray[2], stringArray[4]);

            //int[] numbers = {2, -7, 14};
            //Console.WriteLine("Исходный массив: {0} {1} {2}", numbers[0], numbers[1], numbers[2]);
            //Console.WriteLine("Количество элементов в массиве: {0}", numbers.Length);

            //Array.Reverse(numbers); //развернуть массив
            //Console.WriteLine("Перевернутый массив: {0} {1} {2}", numbers[0], numbers[1], numbers[2]);
            //Array.Sort(numbers);
            //Console.WriteLine("Отсортированный массив: {0} {1} {2}", numbers[0], numbers[1], numbers[2]);
            //Array.Clear(numbers,0,3);
            //Console.WriteLine("Очищенный массив: {0} {1} {2}", numbers[0], numbers[1], numbers[2]);

            //домашнее задание

            //задание 1
            //double[] doubleArray = new[] {1.2, 4.77, 0, -14.22};
            //Array.Sort(doubleArray);
            //Array.Reverse(doubleArray);
            //Console.WriteLine("{0} {1} {2} {3}", doubleArray[0], doubleArray[1], doubleArray[2], doubleArray[3]);

            string[] stringArray = {"Лев", "Зебра", "Жираф"};
            int[] intArray = {3, 5, 5};
            Console.WriteLine("В слове {0} {1} буквы", stringArray[0], intArray[0]);
            Console.WriteLine("В слове {0} {1} буквы", stringArray[1], intArray[1]);
            Console.WriteLine("В слове {0} {1} буквы", stringArray[2], intArray[2]);
        }
    }
}
