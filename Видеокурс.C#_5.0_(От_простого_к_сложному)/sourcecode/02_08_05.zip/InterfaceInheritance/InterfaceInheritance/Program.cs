﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Worker worker = new Worker();
        }
    }

    class Worker : ISkilledDeveloper
    {
        public void DevelopConsoleApplication()
        {
            //
        }

        public void DevelopWebApplication()
        {
            //
        }
    }

    interface IDeveloper
    {
        void DevelopConsoleApplication();
    }

    interface ISkilledDeveloper : IDeveloper
    {
        void DevelopWebApplication();
    }
}
