﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicInheritance
{
    //дочерний (производный) класс Слон
    class Elephant : Animal
    {
        public void Feed()
        {
            Console.WriteLine("Вы покормили слона. Слон доволен.");
        }
    }
}
