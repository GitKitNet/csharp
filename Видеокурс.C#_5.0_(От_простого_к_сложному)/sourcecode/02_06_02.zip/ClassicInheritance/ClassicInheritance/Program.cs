﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Tiger tiger1 = new Tiger("Геральд", 7, 60, 20);

            Elephant elephant1 = new Elephant();
            elephant1.Name = "Малыш";
            elephant1.Feed();
        }
    }
}
