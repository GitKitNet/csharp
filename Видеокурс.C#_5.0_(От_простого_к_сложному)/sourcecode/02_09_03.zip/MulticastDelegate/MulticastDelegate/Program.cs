﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegate
{
    public delegate int SimpleDelegate();

    class Program
    {
        static void Main(string[] args)
        {
            SimpleDelegate dDelegate = SimpleMethod1;
            dDelegate += SimpleMethod2;
            dDelegate += SimpleMethod3;
            int val = dDelegate();
            Console.WriteLine(val);
        }

        static int SimpleMethod1()
        {
            Console.WriteLine("Вызывается метод SimpleMethod1()");
            return 1;
        }
        static int SimpleMethod2()
        {
            Console.WriteLine("Вызывается метод SimpleMethod2()");
            return 2;
        }
        static int SimpleMethod3()
        {
            Console.WriteLine("Вызывается метод SimpleMethod3()");
            return 3;
        }
    }
}
