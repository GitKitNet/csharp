﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            CashMachine.WithdrawMoney(12345, 40000);
            CashMachine.WithdrawMoney(12345, 10000);
            CashMachine.WithdrawMoney(12345, 5000);
        }
    }
}
