﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashMachine
{
    static class CashMachine
    {
        public static string Address { get; set; } //адрес банкомата
        public static string SupportFIO { get; set; } //ФИО сотрудника поддержки
        public static double RoublesAvailable { get; set; } //всего доступно рублей
        public static double DollarsAvailable { get; set; } //всего доступно долларов
        public static double DollarCourse { get; set; } //курс доллара

        //статический конструктор
        static CashMachine()
        {
            Address = "г. Неизвестный, ул. Ленина, 45";
            SupportFIO = "Иванов Иван Иванович";
            RoublesAvailable = 50000;
            DollarsAvailable = 3000;
            DollarCourse = 31.11;
        }

        //снять деньги
        public static double WithdrawMoney(int accountNumber, double amount)
        {
            Console.WriteLine("... снимаем деньги со счета {0} ...", accountNumber);
            if (RoublesAvailable >= amount)
            {
                Console.WriteLine("Операция прошла успешно. Не забудьте забрать вашу банковскую карту.");
                RoublesAvailable = RoublesAvailable - amount;
                return amount;
            }
            Console.WriteLine("Ошибка. В банкомате недостаточно наличных средств.");
            return 0;
        }

        //зачислить деньги на счет
        public static void DepositMoney(int accountNumber, double amount)
        {
            Console.WriteLine("... зачисляем деньги на счет {0} ...", accountNumber);
            Console.WriteLine("Операция прошла успешно. Не забудьте забрать вашу банковскую карту.");
            RoublesAvailable = RoublesAvailable + amount;
        }

        //обменять рубли на доллары
        public static double ChangeRoubles(double amount)
        {
            double result = amount/DollarCourse;
            Console.WriteLine("... обменять рубли на доллары ...");
            if (DollarsAvailable >= result)
            {
                Console.WriteLine("Операция прошла успешно. Не забудьте забрать вашу банковскую карту.");
                DollarsAvailable = DollarsAvailable - result;
                return amount;
            }
            Console.WriteLine("Ошибка. В банкомате недостаточно наличных средств.");
            return 0;
        }

        //обменять доллары на рубли
        public static double ChangeDollars(double amount)
        {
            double result = amount * DollarCourse;
            Console.WriteLine("... обменять доллары на рубли ...");
            if (RoublesAvailable >= result)
            {
                Console.WriteLine("Операция прошла успешно. Не забудьте забрать вашу банковскую карту.");
                RoublesAvailable = RoublesAvailable - result;
                return amount;
            }
            Console.WriteLine("Ошибка. В банкомате недостаточно наличных средств.");
            return 0;
        }
    }
}
