﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashMachineEvents
{
    class Program
    {
        static void Main(string[] args)
        {
            CashMachine cashMachine = new CashMachine(100000);
            cashMachine.NoMoney += () => Console.WriteLine("... возникло событие NoMoney ...");

            cashMachine.WithdrawMoney(50000);
            cashMachine.WithdrawMoney(51000);
        }
    }
}
