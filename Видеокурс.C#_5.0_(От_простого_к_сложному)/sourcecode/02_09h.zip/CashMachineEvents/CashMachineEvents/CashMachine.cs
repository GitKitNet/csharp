﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashMachineEvents
{
    public class CashMachine
    {
        public delegate void NoMoneyDelegate();
        public event NoMoneyDelegate NoMoney;

        public int Money { get; private set; }
        public CashMachine(int money)
        {
            Money = money;
        }

        public void WithdrawMoney(int amount)
        {
            Console.WriteLine("Попытка снять {0} денежных единиц...", amount);
            if (Money >= amount)
            {
                Console.WriteLine("Статус: успешно");
                Money -= amount;
            }
            else
            {
                Console.WriteLine("Статус: неуспешно");
                NoMoney();
            }
        }
    }
}
