﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            //int x = 0;
            //if (x > 0)
            //{
            //    Console.WriteLine("Переменная x > 0");
            //}
            //else if (x == 0)
            //{
            //    Console.WriteLine("Переменная x == 0");
            //}
            //else
            //{
            //    Console.WriteLine("Переменная x < 0");
            //}
            Console.WriteLine("Желаете ли вы провести антивирусную проверку?");
            string answer = Console.ReadLine();
            if (answer == "да")
            {
                Console.WriteLine("... производится антивирусная проверка ...");
            }
            else if (answer == "нет")
            {
                Console.WriteLine("... риск заражения компьютера возрастает ...");
            }
            else
            {
                Console.WriteLine("... ошибка! неизвестная команда ...");
            }
        }
    }
}
