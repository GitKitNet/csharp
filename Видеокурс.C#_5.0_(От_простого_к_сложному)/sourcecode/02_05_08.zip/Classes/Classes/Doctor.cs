﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    class Doctor
    {
        public string Surname { get; set; }
        public string Name { get; set; }
        public string MiddleName { get; set; }

        public string Profession { get; set; } //специальность
        int cabinetNumber; //номер кабинета
        public int CabinetNumber
        {
            get { return cabinetNumber; }
            set
            {
                //в больнице всего 100 кабинетов
                if (value > 100)
                    value = 100;
                cabinetNumber = value;
            }
        }

        public int PatientNumber { get; set; } //количество вылеченных пациентов
        public static int Salary { get; set; } //зарплата

        //статический конструктор
        static Doctor()
        {
            Salary = 100000;
        }

        //конструктор по умолчанию
        public Doctor()
        {
        }

        //конструктор с тремя параметрами - ФИО
        public Doctor(string surname, string name, string middleName)
        {
            Surname = surname;
            Name = name;
            MiddleName = middleName;
        }

        //конструктор с одним параметром - кол-во вылеченных пациентов
        public Doctor(int patientNumberParameter)
        {
            PatientNumber = patientNumberParameter;
            Surname = "Тестовый";
            Name = "Врач";
            MiddleName = "Без отчества";
            Profession = "Неопределена";
            CabinetNumber = 1;
        }

        //метод выводит информацию о враче на консоль
        public void PrintBio()
        {
            Console.WriteLine("Врач {0} {1} {2} имеет специальность \"{3}\" и работает в кабинете {4}. Он вылечил уже {5} пациента(ов). Зарплата составляет {6}.\n", Surname, Name, MiddleName, Profession, CabinetNumber, PatientNumber, Salary);
        }

        //метод "пойти на работу"
        public void GoToWork()
        {
            Console.WriteLine("Врач {0} {1} {2} пошел на работу...", Surname, Name, MiddleName);
            PatientNumber = PatientNumber + 5;
        }

        //статический метод. Выводит информацию о классе на консоль
        public static void PrintClassInfo()
        {
            Console.WriteLine("Класс Doctor представляет в программе бизнес-сущность \"Врач\". В классе определен один статический конструктор, ...");
        }
    }
}
