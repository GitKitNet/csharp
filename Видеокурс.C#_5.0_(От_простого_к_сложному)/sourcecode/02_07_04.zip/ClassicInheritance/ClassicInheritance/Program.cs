﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            //Tiger tiger1 = new Tiger();
            //Animal tiger2 = new Tiger();
            //object tiger3 = new Tiger();

            //неявное приведение
            Tiger tiger = new Tiger("Молчун", 5, 60, 20);
            PrintAnimalName(tiger);

            //явное приведение
            Animal tiger2 = new Tiger("Молчун", 5, 60, 20);
            PrintTailLength((Tiger) tiger2);
        }

        //полиморфное поведение
        static void PrintAnimalName(Animal animal)
        {
            //if(animal is Tiger)
            //    Console.WriteLine("Передан объект класса Tiger.");
            //if (animal is Elephant)
            //    Console.WriteLine("Передан объект класса Elephant.");
            if (animal as Tiger != null)
                Console.WriteLine("Передан объект класса Tiger.");
            if (animal as Elephant != null)
                Console.WriteLine("Передан объект класса Elephant.");
            Console.WriteLine(animal.Name);
        }

        static void PrintTailLength(Tiger tiger)
        {
            Console.WriteLine(tiger.TailLength);
        }
    }
}
