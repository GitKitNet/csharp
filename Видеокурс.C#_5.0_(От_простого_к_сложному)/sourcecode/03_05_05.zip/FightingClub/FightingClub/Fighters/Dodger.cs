﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FightingClub.Fighters
{
    public class Dodger : Fighter
    {
        public Dodger(string name = "имя должен выбрать игрок")
            : base(
            name, 
            "Изворотливый ловкач",
            "Ловкость рук - Есть 25% шанс запутать противника и незаметно ударить второй рукой. Такой удар считается критическим попаданием (x3)",
            3, 4, 3)
        {
            
        }

        public override int UseUltimateAbility()
        {
            throw new NotImplementedException();
        }
    }
}
