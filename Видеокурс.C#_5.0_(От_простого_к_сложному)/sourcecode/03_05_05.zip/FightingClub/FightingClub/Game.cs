﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FightingClub
{
    //в этом классе определена логика игры
    public class Game
    {
        public void StartGame()
        {
            
        }
    }
}
