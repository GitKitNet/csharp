﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessModificators
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassA classA = new ClassA();
            classA.Property1 = 111;
            ClassB classB = new ClassB();
            
        }
    }
}
