﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessModificators
{
    public class ClassA
    {
        internal int Property1 { get; set; }
        int property2;
        public int Property2
        {
            get { return property2; }
            set { property2 = value; }
        }
        protected int Property3 { get; set; }
    }
}
