﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            //массив объектов, совместимых с Animal
            Animal[] animals = {new Tiger(), new Tiger(), new Elephant(), new Elephant(), new Elephant()};

            //перечислить все элементы в массиве
            foreach (Animal animal in animals)
            {
                //используем интерфейс абстрактного базового класса Animal
                animal.Feed();
            }
        }
    }
}
