﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            AddTwoNumbers(3, 4);
            AddTwoNumbers(10,20);
            AddTwoNumbers(-2,0);
            TypeMessage("Hello");
        }

        //метод для сложения двух чисел
        static void AddTwoNumbers(int x, int y)
        {
            int result = x + y;
            Console.WriteLine("{0} + {1} = {2}", x, y, result);
        }

        //метод выводит на консоль сообщение
        static void TypeMessage(string message)
        {
            message = message + "!!!";
            Console.WriteLine(message);
        }
    }
}
