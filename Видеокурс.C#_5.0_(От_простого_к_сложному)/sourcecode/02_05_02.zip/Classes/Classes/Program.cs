﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            Doctor doctor1 = new Doctor();
            doctor1.surname = "Иванов";
            doctor1.name = "Иван";
            doctor1.middleName = "Иванович";
            doctor1.profession = "Терапевт";
            doctor1.cabinetNumber = 15;
            doctor1.patientNumber = 0;
            
            Doctor doctor2 = new Doctor();
            doctor2.surname = "Петров";
            doctor2.name = "Петр";
            doctor2.middleName = "Петрович";
            doctor2.profession = "Офтальмолог";
            doctor2.cabinetNumber = 4;
            doctor2.patientNumber = 0;

            doctor2.PrintBio();
            doctor2.GoToWork();
            doctor2.GoToWork();
            doctor2.GoToWork();
            doctor2.PrintBio();
        }
    }
}
