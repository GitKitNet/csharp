﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    class Doctor
    {
        public string surname;
        public string name;
        public string middleName;

        public string profession; //специальность
        public int cabinetNumber; //номер кабинета
        public int patientNumber; //количество вылеченных пациентов

        //метод выводит информацию о враче на консоль
        public void PrintBio()
        {
            Console.WriteLine("Врач {0} {1} {2} имеет специальность \"{3}\" и работает в кабинете {4}. Он вылечил уже {5} пациента(ов)", surname, name, middleName, profession, cabinetNumber, patientNumber);
        }

        //метод "пойти на работу"
        public void GoToWork()
        {
            Console.WriteLine("Врач {0} {1} {2} пошел на работу...", surname, name, middleName);
            patientNumber = patientNumber + 5;
        }
    }
}
