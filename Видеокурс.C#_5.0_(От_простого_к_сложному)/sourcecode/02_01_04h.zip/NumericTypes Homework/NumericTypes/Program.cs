﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumericTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10;
            int y = 5;
            int z;

            //арифметические операции
            z = x + y;  //15
            z = x - y; //5
            z = x*y; //50
            z = x / y; //2
            z = x%y; //0
            z = x + x + x - y - x; //15

            double a = 3, b = 2;
            //Console.WriteLine(a/b);
            double c = a/b;

            //операции инкремента и декремента
            int k = 15;
            k++;
            //Console.WriteLine(k); //16
            k--;
            //Console.WriteLine(k); //15

            int n = 0, m = 0;
            //Console.WriteLine(n++); //выводит 0, теперь n = 1
            //Console.WriteLine(++m); //выводит 1, теперь m = 1

            //знакомство с классом Math
            double p = Math.Pow(4, 3);
            //Console.WriteLine(p);

            double q = Math.Max(100, 117);
            //Console.WriteLine(q);


            //Домашнее задание
            int days = 7;
            Console.WriteLine("Количество дней в неделе: {0}", days);
            int weeks = 4*12;
            Console.WriteLine("Количество недель в году: {0}", weeks);
            int daysTotal = days*weeks;
            Console.WriteLine("Общее количество дней в году: {0}", daysTotal);
        }
    }
}
