﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    //интерфейс определяет поведение "Определить количество вершин геометрической фигуры"
    public interface IPoints
    {
        int CalculatePoints();
    }
}
