﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Piatiugolnik : Mnogougolnik, IPoints
    {
        public override void Draw()
        {
            Console.WriteLine("Рисуется пятиугольник...");
        }

        public int CalculatePoints()
        {
            return 5;
        }
    }
}
