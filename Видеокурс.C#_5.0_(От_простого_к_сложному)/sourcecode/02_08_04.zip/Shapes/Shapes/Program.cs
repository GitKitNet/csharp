﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Program
    {
        static void Main(string[] args)
        {
            Treugolnik treugolnik = new Treugolnik();
            
            Figura[] figuras = {new Chetirehugolnik(), new Krug(), new Oval(), new Piatiugolnik(), new Treugolnik()};
            //Print(figuras);

            IPoints[] shapes = {new Piatiugolnik(), new Treugolnik(), new Treugolnik(), new Chetirehugolnik()};
            FindShapeWithMaxPoints(shapes);
        }

        static void Print(Figura[] figuras)
        {
            foreach (Figura figura in figuras)
            {
                figura.Draw();
                if(figura is IPoints)
                    Console.WriteLine("В этой фигуре {0} вершин(ы)", ((IPoints)figura).CalculatePoints());
            }
        }

        static void FindShapeWithMaxPoints(IPoints[] shapes)
        {
            int max = 0;
            foreach (IPoints shape in shapes)
            {
                if (shape.CalculatePoints() > max)
                    max = shape.CalculatePoints();
            }
            Console.WriteLine("Среди всех фигур максимальное число вершин: {0}", max);
        }
    }
}
