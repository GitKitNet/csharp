﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            ////используем конструктор по умолчанию
            //Doctor doctor1 = new Doctor();
            //doctor1.PrintBio();

            ////используем специальный конструктор и передаем значения ФИО
            //Doctor doctor2 = new Doctor("Иванов", "Иван", "Иванович");
            //doctor2.PrintBio();

            ////передаем в конструктор кол-во вылеченных больных
            //Doctor doctor3 = new Doctor(10000);
            //doctor3.PrintBio();

            ////изменилось бизнес-правило
            //Doctor.salary = 150000;
            //Console.WriteLine("*** ИЗМЕНИЛОСЬ БИЗНЕС-ПРАВИЛО ***");
            //doctor1.PrintBio();
            //doctor2.PrintBio();
            //doctor3.PrintBio();
            //Doctor.PrintClassInfo();
            Service.SendEmail("asd@dsa.ru");
        }
    }
}
