﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    class Doctor
    {
        public string surname;
        public string name;
        public string middleName;

        public string profession; //специальность
        public int cabinetNumber; //номер кабинета
        public int patientNumber; //количество вылеченных пациентов
        public static int salary; //зарплата

        //статический конструктор
        static Doctor()
        {
            salary = 100000;
        }

        //конструктор по умолчанию
        public Doctor()
        {
        }

        //конструктор с тремя параметрами - ФИО
        public Doctor(string surname, string name, string middleName)
        {
            this.surname = surname;
            this.name = name;
            this.middleName = middleName;
        }

        //конструктор с одним параметром - кол-во вылеченных пациентов
        public Doctor(int patientNumberParameter)
        {
            patientNumber = patientNumberParameter;
            surname = "Тестовый";
            name = "Врач";
            middleName = "Без отчества";
            profession = "Неопределена";
            cabinetNumber = 1;
        }

        //метод выводит информацию о враче на консоль
        public void PrintBio()
        {
            Console.WriteLine("Врач {0} {1} {2} имеет специальность \"{3}\" и работает в кабинете {4}. Он вылечил уже {5} пациента(ов). Зарплата составляет {6}.\n", surname, name, middleName, profession, cabinetNumber, patientNumber, salary);
        }

        //метод "пойти на работу"
        public void GoToWork()
        {
            Console.WriteLine("Врач {0} {1} {2} пошел на работу...", surname, name, middleName);
            patientNumber = patientNumber + 5;
        }

        //статический метод. Выводит информацию о классе на консоль
        public static void PrintClassInfo()
        {
            Console.WriteLine("Класс Doctor представляет в программе бизнес-сущность \"Врач\". В классе определен один статический конструктор, ...");
        }
    }
}
