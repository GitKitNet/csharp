﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InclusionInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Office office = new Office();
            office.Number = 1;
            office.CompProperty.SerialNumber = 123;
            office.CompProperty.TurnOn();
        }
    }
}
