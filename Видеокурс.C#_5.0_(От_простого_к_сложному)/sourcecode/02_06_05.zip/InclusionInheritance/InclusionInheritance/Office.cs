﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InclusionInheritance
{
    public class Office
    {
        public int Number { get; set; }

        public class Computer
        {
            public int SerialNumber { get; set; }
            public void TurnOn()
            {
                //
            }
        }

        public Computer CompProperty { get; set; }

        public Office()
        {
            CompProperty = new Computer();
        }
    }


}
